
import cv2
import matplotlib.pyplot as plt

def adjust_brightness(image_path, brightness_increase):
    """
    Adjust the brightness of an image.

    Parameters:
    - image_path: Path to the input image.
    - brightness_increase: Amount to increase the brightness.

    Returns:
    - Brightened image.
    """
    # Load the image from file
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Unable to load image from {image_path}")
        return None

    # Adjust the brightness using cv2.convertScaleAbs
    bright_image = cv2.convertScaleAbs(image, alpha=1, beta=brightness_increase)
    return bright_image

# Path to the input image
image_path = '/content/lowbight_image.jpeg'
# Amount to increase the brightness
brightness_increase = 50

# Adjust the brightness of the image
bright_image = adjust_brightness(image_path, brightness_increase)

if bright_image is not None:
    # Display the brightened image
    plt.imshow(cv2.cvtColor(bright_image, cv2.COLOR_BGR2RGB))
    plt.title('Brightened Image')
    plt.axis('off')
    plt.show()
